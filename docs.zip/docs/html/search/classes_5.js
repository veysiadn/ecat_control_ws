var searchData=
[
  ['receiveddata_388',['ReceivedData',['../structReceivedData.html',1,'']]]
];
