var searchData=
[
  ['diff_5fns_635',['DIFF_NS',['../ecat__globals_8hpp.html#aff98fed4398150e17dbcd151445065ee',1,'ecat_globals.hpp']]]
];
