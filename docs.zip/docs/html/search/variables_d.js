var searchData=
[
  ['nominal_5fcurrent_533',['nominal_current',['../structCSPositionModeParam.html#a4cab3ece9f13d718af0e3861fcc0878e',1,'CSPositionModeParam::nominal_current()'],['../structCSVelocityModeParam.html#a4c719dd836fcc38a4413f045220dea5e',1,'CSVelocityModeParam::nominal_current()'],['../structCSTorqueModeParam.html#a761a81f7e2d27a4cdab0ac823d494021',1,'CSTorqueModeParam::nominal_current()']]]
];
